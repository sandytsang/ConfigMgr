﻿<#	
	.NOTES
	===========================================================================

	.DESCRIPTION
		Designed to be used in SCCM Task Sequence.
		Script connects to SCCM database, searches for applications based on these filters:
		- Application Administrative Category is "OSD Apps"
		- Application is not retired
		- Application is latest revision
		Creates Dynamic Variable List of applications to be used in Task Sequences Install Application step.
#>

Begin
{
	# Construct TSEnv object
	try
	{
		$TSEnv = New-Object -ComObject Microsoft.SMS.TSEnvironment -ErrorAction Stop
	}
	catch [System.Exception] {
		Write-Warning -Message "Unable to construct Microsoft.SMS.TSEnvironment object"; exit 1
	}
}
Process
{
	#Cmtrace Log Function
	function Write-CMLogEntry
	{
		param (
			[parameter(Mandatory = $true, HelpMessage = "Value added to the smsts.log file")]
			[ValidateNotNullOrEmpty()]
			[string]$Value,
			[parameter(Mandatory = $true, HelpMessage = "Severity for the log entry. 1 for Informational, 2 for Warning and 3 for Error.")]
			[ValidateNotNullOrEmpty()]
			[ValidateSet("1", "2", "3")]
			[string]$Severity
		)
		# Determine log file location
		$LogFilePath = Join-Path -Path $Script:TSEnv.Value("_SMSTSLogPath") -ChildPath "GetCategoryDynamicAppList.log"
		
		# Construct time stamp for log entry
		$Time = -join @((Get-Date -Format "HH:mm:ss.fff"), "+", (Get-WmiObject -Class Win32_TimeZone | Select-Object -ExpandProperty Bias))
		
		# Construct date for log entry
		$Date = (Get-Date -Format "MM-dd-yyyy")
		
		# Construct context for log entry
		$Context = $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
		
		# Construct final log entry
		$LogText = "<![LOG[$($Value)]LOG]!><time=""$($Time)"" date=""$($Date)"" component=""GetCategoryDynamicAppList"" context=""$($Context)"" type=""$($Severity)"" thread=""$($PID)"" file="""">"
		
		# Add value to log file
		try
		{
			Add-Content -Value $LogText -LiteralPath $LogFilePath -ErrorAction Stop
		}
		catch [System.Exception] {
			Write-Warning -Message "Unable to append log entry to smsts.log file"
		}
	}
	
	
	#SCCM Server informations
	$SiteCode = "Your site code"
	$SiteServer = "Your site server"
	
	#service account that will run the remote session. 
	#Get Service Account name from collection variable
	#Reade https://sccmentor.com/2015/03/12/dynamically-deploying-packages-and-applications-to-computers-using-a-task-sequence-via-powershell-in-configmgr-2012/  , Section 1 – Some local variables defined
	$svcaccname = $tsenv.value("svcaccname")
	#Get Service Account password from collection variable
	$svcaccpassword = $tsenv.Value("svcaccpassword")
	$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList @($svcaccname, (ConvertTo-SecureString -String $svcaccpassword -AsPlainText -Force))
	
	
	#Get Applications based on Category name "OSD Apps"
	$Query = "LocalizedCategoryInstanceNames='OSD Apps' and IsExpired='False' and IsLatest='True'"
	$CMApps = Get-WmiObject -ComputerName $SiteServer -Class SMS_Application -Namespace root/sms/site_$sitecode -Filter $Query -Credential $Cred
	
	#Assign Variable to Applications.
	if ($CMApps -ne $null)
	{
		Write-CMLogEntry -Value "Searching OSD applications to install..." -Severity 1
		
		$Count = 1

	<#	
		.NOTES
		===========================================================================
		This is Optional, if you want to priority some application be installed first, add them one by one here.
	
		===========================================================================
		
		#If you would like to install "Adobe Reader" as first.
		$ApplicationName = ($CMApps | where-object { $_.LocalizedDisplayName -match "Adobe Reader" }).LocalizedDisplayName
		if ($ApplicationName)
		{
			$Id = "{00:D2}" -f $Count
			$OSDAppID = "AppID$Id"
			$TSEnv.Value($OSDAppID) = $ApplicationName	
			Write-CMLogEntry -Value "Add $OSDAppID $Applicationname to variable list" -Severity 1
			$Count = $Count + 1
		}
		
		#If you would like to install "Java" as second
		$ApplicationName = ($CMApps | where-object { $_.LocalizedDisplayName -match "Java" }).LocalizedDisplayName
		if ($ApplicationName)
		{
			$Id = "{00:D2}" -f $Count
			$OSDAppID = "AppID$Id"
			$TSEnv.Value($OSDAppID) = $ApplicationName
			Write-CMLogEntry -Value "Add $OSDAppID $Applicationname to variable list" -Severity 1
			$Count = $Count + 1
		}
		
		===========================================================================
	#>
		
		#If you have assinged install "Adobe Reader" and "Java" in the Optional step, then use line 122 and remove line 124 "foreach ($App in ($CMApps)"
		#foreach ($App in ($CMApps | where-object { $_.LocalizedDisplayName -notmatch "Adobe Reader" -and $_.LocalizedDisplayName -notmatch "Java" }))

		foreach ($App in $CMApps)
		{			
			$Id = "{0:D2}" -f $Count
			$OSDAppID = "AppID$Id"
			$ApplicationName = $app.LocalizedDisplayName
			$TSEnv.Value($OSDAppID) = $ApplicationName
			#Write-Host " $OSDAppID $Applicationname"
			Write-CMLogEntry -Value "Add $OSDAppID $Applicationname to variable list" -Severity 1
			$Count = $Count + 1
		}
		
	}
	else
	{
		$TSEnv.Value("SkipOSDApps") = "TRUE"
		Write-CMLogEntry -Value "No OSD applications to install - skipping installation step" -Severity 2
		#Write-Host " No OSD applications to install - skipping installation step"
	}
}