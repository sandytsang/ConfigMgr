﻿<#	
	.NOTES
	===========================================================================

	 Created on:   	29.11.2016 20.47
	 Created by:   	Yinghua Zeng

	 Filename:     	
	===========================================================================
	.DESCRIPTION
		-Dynamic Variable COALESCEDAPPS* List
		-Check if Applications installed
		-Write results to registry
#>

Begin
{
	# Construct TSEnv object
	try
	{
		$TSEnv = New-Object -ComObject Microsoft.SMS.TSEnvironment -ErrorAction Stop
	}
	catch [System.Exception] {
		Write-Warning -Message "Unable to construct Microsoft.SMS.TSEnvironment object"; exit 1
	}
}
Process
{
	# Functions 
	
	function Write-CMLogEntry
	{
		param (
			[parameter(Mandatory = $true, HelpMessage = "Value added to the smsts.log file")]
			[ValidateNotNullOrEmpty()]
			[string]$Value,
			[parameter(Mandatory = $true, HelpMessage = "Severity for the log entry. 1 for Informational, 2 for Warning and 3 for Error.")]
			[ValidateNotNullOrEmpty()]
			[ValidateSet("1", "2", "3")]
			[string]$Severity
		)
		# Determine log file location
		$LogFilePath = Join-Path -Path $Script:TSEnv.Value("_SMSTSLogPath") -ChildPath "GetInstalledApps.log"
		
		# Construct time stamp for log entry
		$Time = -join @((Get-Date -Format "HH:mm:ss.fff"), "+", (Get-WmiObject -Class Win32_TimeZone | Select-Object -ExpandProperty Bias))
		
		# Construct date for log entry
		$Date = (Get-Date -Format "MM-dd-yyyy")
		
		# Construct context for log entry
		$Context = $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)
		
		# Construct final log entry
		$LogText = "<![LOG[$($Value)]LOG]!><time=""$($Time)"" date=""$($Date)"" component=""GetInstalledApps"" context=""$($Context)"" type=""$($Severity)"" thread=""$($PID)"" file="""">"
		
		# Add value to log file
		try
		{
			Add-Content -Value $LogText -LiteralPath $LogFilePath -ErrorAction Stop
		}
		catch [System.Exception] {
			Write-Warning -Message "Unable to append log entry to smsts.log file"
		}
	}
	
	Write-CMLogEntry -Value "Start Scan Installed Applications" -Severity 1
	
	#SCCM Server informations
	$SiteCode = "Your site code"
	$SiteServer = "Your site server"
	
	#service account that will run the remote session. 
	#Get Service Account name from collection variable
	#Reade https://sccmentor.com/2015/03/12/dynamically-deploying-packages-and-applications-to-computers-using-a-task-sequence-via-powershell-in-configmgr-2012/  , Section 1 – Some local variables defined
	$svcaccname = $tsenv.value("svcaccname")
	#Get Service Account password from collection variable
	$svcaccpassword = $tsenv.Value("svcaccpassword")
	$Cred = New-Object System.Management.Automation.PSCredential -ArgumentList @($svcaccname, (ConvertTo-SecureString -String $svcaccpassword -AsPlainText -Force))

	#Create OSDResult registry
	$RegPath = "hklm:\Software\Microsoft\MPSD\OSD"
	New-Item -Path $RegPath -ErrorAction SilentlyContinue

	#Scan Intsalled SCCM Applications	
	$InstalledApps = get-wmiobject -computername $env:COMPUTERNAME -query "SELECT * FROM CCM_Application" -namespace "ROOT\ccm\clientsdk" | select FullName, id, InstallState
	
	write-host "Gathering CM Applications..."
	#Get Applications based on Category name "OSD Apps"
	$Query = "LocalizedCategoryInstanceNames='OSD Apps' and IsExpired='False' and IsLatest='True'"
	$CMApps = Get-WmiObject -ComputerName $SiteServer -Class SMS_Application -Namespace root/sms/site_$sitecode -Filter $Query -Credential $Cred

	#Assign Variable to Applications.
	if ($CMApps -ne $null)
	{
		Write-CMLogEntry -Value "Searching OSD applications to install..." -Severity 1
		
		$Count = 1

		$InstalledAppsArray = foreach ($App in $CMApps)
		{		
			$Id = "{00:D3}" -f $Count		
			$OSDAppID = "COALESCEDAPPS$Id"
			$ApplicationName = $app.LocalizedDisplayName
			Write-CMLogEntry -Value "Writting $OSDAppID value $ApplicationName to $RegPath" -Severity 1
			Set-itemProperty $RegPath -name "$OSDAppID" -value "$ApplicationName" -type String -Force
			$Count = $Count + 1
						
			$ApplicationGUID = $App.ModelName
			$AppInstallStatus = ($InstalledApps | Where-Object { $_.id -like $ApplicationGUID }).InstallState
			if ($AppInstallStatus -like "Installed")
			{
				$WriteArrayToRegistry = $ApplicationName + ':1'
				Write-CMLogEntry -Value "$WriteArrayToRegistry" -Severity 1
			}
			else
			{
				$WriteArrayToRegistry = $ApplicationName + ':0'
				Write-CMLogEntry -Value "$WriteArrayToRegistry" -Severity 1
			}
			
			$WriteArrayToRegistry
			
		}
		
	}

	
	Write-CMLogEntry -Value "adding $InstalledAppsArray to InstalledApps" -Severity 1
	Set-itemProperty $RegPath -name "InstalledApps" -value $InstalledAppsArray -type MultiString -Force
	
	Write-CMLogEntry -Value "adding TsApplicationBaseVariable value COALESCEDAPPS to $RegPath" -Severity 1
	Set-itemProperty $RegPath -name "TsApplicationBaseVariable" -value 'COALESCEDAPPS' -type String -Force
	
	Write-CMLogEntry -Value "adding OSDBaseVariableName value Applications to $RegPath" -Severity 1
	Set-itemProperty $RegPath -name "OSDBaseVariableName" -value 'PACKAGES' -type String -Force
	
}
